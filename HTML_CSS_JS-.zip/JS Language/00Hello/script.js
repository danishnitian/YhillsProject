console.log("Hello World!");

function alertTheUser() {
  console.log("alertTheUser() << ");
  alert("STOP SLEEPING AND START WORKING");
  console.log("alertTheUser() >> ");
}
